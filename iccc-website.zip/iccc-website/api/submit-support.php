<?php
/**
 * Request Support — the only endpoint that accepts documents.
 * Everything written to disk here is encrypted; nothing is stored under the web root.
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

iccc_begin_submission('support');

$config = iccc_config();

$alias   = iccc_field('alias', 120);
$email   = iccc_field('email', 200);
$story   = iccc_field('story', 8000);
$country = iccc_field('country', 100);

if ($alias === '' || $country === '' || $story === '') {
    iccc_json(['ok' => false, 'error' => 'Please complete the required fields.'], 422);
}
if ($email !== '' && !iccc_valid_email($email)) {
    iccc_json(['ok' => false, 'error' => 'That email address is not valid.'], 422);
}
foreach (['consent_true', 'consent_store', 'consent_referral'] as $consent) {
    if (($_POST[$consent] ?? '') !== 'yes') {
        iccc_json(['ok' => false, 'error' => 'Please confirm all three consent statements.'], 422);
    }
}

$reference = iccc_reference();
$stored    = [];

/* ----------------------------------------------------------- attachments */
if (!empty($_FILES['documents']['name'][0])) {
    $files = $_FILES['documents'];
    $count = count($files['name']);

    if ($count > (int) $config['max_files']) {
        iccc_json(['ok' => false, 'error' => 'Too many files.'], 422);
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);

    for ($i = 0; $i < $count; $i++) {
        if ((int) $files['error'][$i] !== UPLOAD_ERR_OK) {
            iccc_json(['ok' => false, 'error' => 'One of the files did not upload correctly.'], 422);
        }
        if ((int) $files['size'][$i] > (int) $config['max_file_bytes']) {
            iccc_json(['ok' => false, 'error' => 'One of the files is larger than 10 MB.'], 422);
        }
        if (!is_uploaded_file($files['tmp_name'][$i])) {
            iccc_json(['ok' => false, 'error' => 'Upload rejected.'], 400);
        }

        $ext = strtolower(pathinfo((string) $files['name'][$i], PATHINFO_EXTENSION));
        if (!in_array($ext, $config['allowed_ext'], true)) {
            iccc_json(['ok' => false, 'error' => 'That file type is not accepted.'], 422);
        }

        $mime = (string) $finfo->file($files['tmp_name'][$i]);
        if (!in_array($mime, $config['allowed_mime'], true)) {
            iccc_json(['ok' => false, 'error' => 'That file type is not accepted.'], 422);
        }

        /* The original name is kept only inside the encrypted record. The file on
           disk gets a random name, no extension, and encrypted contents, so it can
           never be executed or guessed. */
        $blobName = bin2hex(random_bytes(16));
        $plain    = (string) file_get_contents($files['tmp_name'][$i]);
        $target   = iccc_storage('uploads') . '/' . $blobName;

        file_put_contents($target, iccc_encrypt($plain), LOCK_EX);
        @chmod($target, 0600);
        @unlink($files['tmp_name'][$i]);

        $stored[] = [
            'blob'          => $blobName,
            'original_name' => substr(preg_replace('/[^\p{L}\p{N}\.\-_ ]/u', '', (string) $files['name'][$i]) ?? 'file', 0, 120),
            'mime'          => $mime,
            'size'          => (int) $files['size'][$i],
        ];
    }
}

/* --------------------------------------------------------------- the case */
$record = [
    'reference'  => $reference,
    'type'       => 'support',
    'status'     => 'new',
    'created_at' => gmdate('c'),
    'alias'      => $alias,
    'email'      => $email,
    'channel'    => iccc_field('channel', 200),
    'reply_lang' => iccc_field('reply_lang', 40),
    'country'    => $country,
    'city'       => iccc_field('city', 100),
    'situation'  => iccc_field('status', 100),
    'needs'      => iccc_field_list('needs'),
    'story'      => $story,
    'files'      => $stored,
    'form_lang'  => iccc_field('_lang', 5),
    /* Deliberately not stored: IP address, user agent, browser fingerprint. */
];

$id = iccc_store_record('support', $record);
iccc_audit('support.created', $reference);

/* The alert carries the reference only — never the contents. */
iccc_notify(
    'ICCC: new support request ' . $reference,
    "A new support request was received.\nReference: {$reference}\nOpen the admin panel to read it."
);

iccc_json(['ok' => true, 'reference' => $reference, 'id' => $id, 'token' => iccc_csrf_token()]);
