<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
iccc_begin_submission('contact');

$name    = iccc_field('name', 150);
$email   = iccc_field('email', 200);
$message = iccc_field('message', 5000);
if ($name === '' || !iccc_valid_email($email) || $message === '') {
    iccc_json(['ok' => false, 'error' => 'Please complete the required fields.'], 422);
}
if (($_POST['consent_store'] ?? '') !== 'yes') {
    iccc_json(['ok' => false, 'error' => 'Please confirm your consent.'], 422);
}

$reference = iccc_reference();
iccc_store_record('contact', [
    'reference'  => $reference,
    'type'       => 'contact',
    'status'     => 'new',
    'created_at' => gmdate('c'),
    'name'       => $name,
    'email'      => $email,
    'subject'    => iccc_field('subject', 200),
    'message'    => $message,
    'form_lang'  => iccc_field('_lang', 5),
]);
iccc_audit('contact.created', $reference);
iccc_notify('ICCC: new message ' . $reference, "A new message arrived.\nReference: {$reference}");
iccc_json(['ok' => true, 'reference' => $reference, 'token' => iccc_csrf_token()]);
