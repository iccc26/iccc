<?php
/**
 * Iranian Civil Community CIC — shared backend helpers.
 *
 * Everything sensitive goes through this file: sessions, CSRF, encryption,
 * storage paths, rate limiting and the audit log.
 */

declare(strict_types=1);

function iccc_config(): array
{
    static $config = null;
    if ($config === null) {
        $path = __DIR__ . '/config.php';
        if (!is_file($path)) {
            iccc_json(['ok' => false, 'error' => 'Server is not configured yet.'], 500);
        }
        $config = require $path;
    }
    return $config;
}

/* ------------------------------------------------------------------ session */

function iccc_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $https,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_name('iccc_sess');
    session_start();

    if (empty($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } elseif (time() - $_SESSION['created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }
}

/* -------------------------------------------------------------------- CSRF */

function iccc_csrf_token(): string
{
    iccc_session();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function iccc_csrf_check(string $token): bool
{
    iccc_session();
    return !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}

/* ------------------------------------------------------------------ output */

function iccc_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function iccc_check_origin(): void
{
    $config = iccc_config();
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin === '' || empty($config['allowed_origins'])) {
        return; // same-origin form posts often omit Origin
    }
    if (!in_array($origin, $config['allowed_origins'], true)) {
        iccc_json(['ok' => false, 'error' => 'Request blocked.'], 403);
    }
}

/* -------------------------------------------------------------- encryption */

function iccc_key(): string
{
    $key = base64_decode(iccc_config()['encryption_key'] ?? '', true);
    if ($key === false || strlen($key) !== 32) {
        iccc_json(['ok' => false, 'error' => 'Server is not configured yet.'], 500);
    }
    return $key;
}

/** AES-256-GCM. Returns iv|tag|ciphertext as raw bytes. */
function iccc_encrypt(string $plain): string
{
    $iv     = random_bytes(12);
    $tag    = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', iccc_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) {
        throw new RuntimeException('Encryption failed.');
    }
    return $iv . $tag . $cipher;
}

function iccc_decrypt(string $blob): string
{
    $iv     = substr($blob, 0, 12);
    $tag    = substr($blob, 12, 16);
    $cipher = substr($blob, 28);
    $plain  = openssl_decrypt($cipher, 'aes-256-gcm', iccc_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($plain === false) {
        throw new RuntimeException('Decryption failed.');
    }
    return $plain;
}

/* ----------------------------------------------------------------- storage */

function iccc_storage(string $sub = ''): string
{
    $base = rtrim(iccc_config()['storage_dir'], '/');
    $path = $sub === '' ? $base : $base . '/' . trim($sub, '/');
    if (!is_dir($path)) {
        @mkdir($path, 0700, true);
    }
    return $path;
}

/** Saves an encrypted record and returns its id. */
function iccc_store_record(string $type, array $record): string
{
    $id   = date('Ymd-His') . '-' . bin2hex(random_bytes(4));
    $file = iccc_storage('records/' . $type) . '/' . $id . '.enc';
    file_put_contents($file, iccc_encrypt(json_encode($record, JSON_UNESCAPED_UNICODE)), LOCK_EX);
    @chmod($file, 0600);
    return $id;
}

function iccc_read_record(string $type, string $id): ?array
{
    $file = iccc_storage('records/' . $type) . '/' . basename($id) . '.enc';
    if (!is_file($file)) {
        return null;
    }
    $data = json_decode(iccc_decrypt((string) file_get_contents($file)), true);
    return is_array($data) ? $data : null;
}

function iccc_list_records(string $type): array
{
    $dir   = iccc_storage('records/' . $type);
    $files = glob($dir . '/*.enc') ?: [];
    rsort($files);
    return array_map(fn($f) => basename($f, '.enc'), $files);
}

/* ------------------------------------------------------------- rate limits */

function iccc_rate_limit(string $bucket): void
{
    $config = iccc_config();
    $ip     = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $file   = iccc_storage('ratelimit') . '/' . $bucket . '-' . sha1($ip) . '.json';

    $now  = time();
    $hits = is_file($file) ? (json_decode((string) file_get_contents($file), true) ?: []) : [];
    $hits = array_values(array_filter($hits, fn($t) => $t > $now - (int) $config['rate_window']));

    if (count($hits) >= (int) $config['rate_limit']) {
        iccc_json(['ok' => false, 'error' => 'Too many submissions. Please try again later.'], 429);
    }
    $hits[] = $now;
    file_put_contents($file, json_encode($hits), LOCK_EX);
}

/* --------------------------------------------------------------- audit log */

function iccc_audit(string $action, string $detail = ''): void
{
    $line = json_encode([
        'at'     => gmdate('c'),
        'action' => $action,
        'detail' => $detail,
        'user'   => $_SESSION['admin_user'] ?? '-',
        'ip'     => hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . 'iccc'),
    ], JSON_UNESCAPED_UNICODE);
    file_put_contents(iccc_storage('logs') . '/audit.log', $line . "\n", FILE_APPEND | LOCK_EX);
}

/* ------------------------------------------------------------------ inputs */

function iccc_field(string $name, int $max = 500): string
{
    $value = (string) ($_POST[$name] ?? '');
    $value = str_replace(["\0", "\r"], '', $value);
    $value = trim($value);
    if (function_exists('mb_substr')) {
        $value = mb_substr($value, 0, $max);
    }
    return $value;
}

function iccc_field_list(string $name, int $maxItems = 20): array
{
    $values = $_POST[$name] ?? [];
    if (!is_array($values)) {
        $values = [$values];
    }
    return array_slice(array_map(fn($v) => trim((string) $v), $values), 0, $maxItems);
}

function iccc_valid_email(string $email): bool
{
    return $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function iccc_reference(): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code     = '';
    for ($i = 0; $i < 6; $i++) {
        $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    }
    return 'ICC-' . date('y') . '-' . $code;
}

/* ------------------------------------------------------------ notification */

function iccc_notify(string $subject, string $body): void
{
    $config = iccc_config();
    if (empty($config['notify_email'])) {
        return;
    }
    @mail(
        $config['notify_email'],
        '=?UTF-8?B?' . base64_encode($subject) . '?=',
        $body,
        "From: {$config['notify_from']}\r\nContent-Type: text/plain; charset=UTF-8\r\n"
    );
}

/* ---------------------------------------------------- shared POST preamble */

function iccc_begin_submission(string $bucket): void
{
    header('X-Content-Type-Options: nosniff');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        iccc_json(['ok' => false, 'error' => 'Method not allowed.'], 405);
    }
    iccc_check_origin();
    iccc_session();
    if (!iccc_csrf_check((string) ($_POST['_csrf'] ?? ''))) {
        iccc_json(['ok' => false, 'error' => 'Your session expired. Please reload the page and try again.'], 419);
    }
    /* Honeypot: a hidden field real people never fill in. */
    if (trim((string) ($_POST['website_url'] ?? '')) !== '') {
        iccc_json(['ok' => true, 'reference' => iccc_reference()]); // silently drop
    }
    iccc_rate_limit($bucket);
}
