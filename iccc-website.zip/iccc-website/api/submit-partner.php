<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
iccc_begin_submission('partner');

$org   = iccc_field('organisation', 200);
$email = iccc_field('email', 200);
if ($org === '' || !iccc_valid_email($email) || iccc_field('proposal', 5000) === '') {
    iccc_json(['ok' => false, 'error' => 'Please complete the required fields.'], 422);
}
if (($_POST['consent_store'] ?? '') !== 'yes') {
    iccc_json(['ok' => false, 'error' => 'Please confirm your consent.'], 422);
}

$reference = iccc_reference();
iccc_store_record('partner', [
    'reference'    => $reference,
    'type'         => 'partner',
    'status'       => 'new',
    'created_at'   => gmdate('c'),
    'organisation' => $org,
    'person'       => iccc_field('person', 150),
    'role'         => iccc_field('role', 120),
    'email'        => $email,
    'website'      => iccc_field('website', 200),
    'country'      => iccc_field('country', 100),
    'collab_type'  => iccc_field('type', 100),
    'proposal'     => iccc_field('proposal', 5000),
    'form_lang'    => iccc_field('_lang', 5),
]);
iccc_audit('partner.created', $reference);
iccc_notify('ICCC: new partnership enquiry ' . $reference, "A new partnership enquiry arrived.\nReference: {$reference}");
iccc_json(['ok' => true, 'reference' => $reference, 'token' => iccc_csrf_token()]);
