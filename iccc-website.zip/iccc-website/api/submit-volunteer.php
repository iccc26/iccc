<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
iccc_begin_submission('volunteer');

$name  = iccc_field('name', 150);
$email = iccc_field('email', 200);
if ($name === '' || !iccc_valid_email($email) || iccc_field('skills', 1000) === '') {
    iccc_json(['ok' => false, 'error' => 'Please complete the required fields.'], 422);
}
if (($_POST['consent_store'] ?? '') !== 'yes') {
    iccc_json(['ok' => false, 'error' => 'Please confirm your consent.'], 422);
}

$reference = iccc_reference();
iccc_store_record('volunteer', [
    'reference'    => $reference,
    'type'         => 'volunteer',
    'status'       => 'new',
    'created_at'   => gmdate('c'),
    'name'         => $name,
    'email'        => $email,
    'phone'        => iccc_field('phone', 60),
    'country'      => iccc_field('country', 100),
    'city'         => iccc_field('city', 100),
    'languages'    => iccc_field('languages', 300),
    'skills'       => iccc_field('skills', 1000),
    'availability' => iccc_field('availability', 60),
    'about'        => iccc_field('about', 3000),
    'form_lang'    => iccc_field('_lang', 5),
]);
iccc_audit('volunteer.created', $reference);
iccc_notify('ICCC: new volunteer ' . $reference, "A new volunteer registered.\nReference: {$reference}");
iccc_json(['ok' => true, 'reference' => $reference, 'token' => iccc_csrf_token()]);
