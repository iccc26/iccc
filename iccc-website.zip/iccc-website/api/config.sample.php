<?php
/**
 * Iranian Civil Community CIC — configuration
 *
 * 1. Copy this file to config.php
 * 2. Fill in the values below
 * 3. Never commit config.php to Git
 */

return [

    /* ---------------------------------------------------------------
     | Where submissions and uploaded documents are stored.
     | This MUST be outside the public web folder (not under public_html).
     | Create it manually and give the web server write permission (chmod 700).
     ---------------------------------------------------------------*/
    'storage_dir' => dirname(__DIR__, 2) . '/iccc-data',

    /* ---------------------------------------------------------------
     | Encryption key for support cases and uploaded files.
     | Generate once with:
     |   php -r "echo base64_encode(random_bytes(32));"
     | If this key is lost, stored cases can no longer be read. Keep an
     | offline backup somewhere safe.
     ---------------------------------------------------------------*/
    'encryption_key' => 'PASTE_BASE64_32_BYTE_KEY_HERE',

    /* ---------------------------------------------------------------
     | Admin panel login.
     | Generate the hash with:
     |   php -r "echo password_hash('your-strong-password', PASSWORD_DEFAULT);"
     ---------------------------------------------------------------*/
    'admin_users' => [
        'admin' => 'PASTE_PASSWORD_HASH_HERE',
    ],

    /* Optional second factor: a shared TOTP secret is out of scope for phase one,
       so restrict the admin folder by IP as well if your host allows it. */
    'admin_ip_allowlist' => [],   // e.g. ['81.2.3.4']

    /* ---------------------------------------------------------------
     | Notification email. The alert contains only the reference code —
     | never the contents of a request.
     ---------------------------------------------------------------*/
    'notify_email' => 'support@iraniancivilcommunity.org',
    'notify_from'  => 'no-reply@iraniancivilcommunity.org',

    /* Only accept form posts coming from these origins. */
    'allowed_origins' => [
        'https://iraniancivilcommunity.org',
        'https://www.iraniancivilcommunity.org',
    ],

    /* Uploads */
    'max_files'      => 5,
    'max_file_bytes' => 10 * 1024 * 1024,
    'allowed_ext'    => ['pdf', 'jpg', 'jpeg', 'png', 'docx'],
    'allowed_mime'   => [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/zip', // some servers report docx as zip
    ],

    /* Rate limiting: submissions allowed per IP per hour */
    'rate_limit'  => 5,
    'rate_window' => 3600,

    /* Delete support cases automatically after this many days of inactivity */
    'retention_days' => 730,
];
